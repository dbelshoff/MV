public class AtualizarParcelaDto
{
    public DateTime DataVencimento { get; set; }
}
