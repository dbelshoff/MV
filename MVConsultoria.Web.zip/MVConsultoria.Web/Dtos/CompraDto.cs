public class CompraDto
{
    public int Id { get; set; }
    public DateTime DataCompra { get; set; }
    public double ValorTotal { get; set; }
    public int QuantidadeParcelas { get; set; }



    public string NomeCliente { get; set; }
}
