public class CompraCreateDto
{
    public int ClienteId { get; set; }
    public DateTime DataCompra { get; set; }
    public double ValorTotal { get; set; }
    public int QuantidadeParcelas { get; set; }
}
