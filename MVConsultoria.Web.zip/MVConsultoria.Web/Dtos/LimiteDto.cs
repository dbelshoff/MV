public class LimiteDto
{
    public double NovoLimite { get; set; }
}