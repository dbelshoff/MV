using System.ComponentModel.DataAnnotations;

namespace MVConsultoria.Web.Models
{
    public class Administrador : User
    {

    }
}
